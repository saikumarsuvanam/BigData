Databricks published url:

https://databricks-prod-cloudfront.cloud.databricks.com/public/4027ec902e239c93eaaa8714f173bcfc/4316818514119112/2969575649583297/3826498952961589/latest.html

Note:
Please run the code on Spark 2.1.1-db6 (Scala 2.11) in databricks.
-> First, Import the notebook into the databricks.
-> For this part of assignment, we have to attach libraries for Corenlp functions to work.
-> Download the zip file from the stanford website Link:(http://nlp.stanford.edu/software/stanford-corenlp-full-2015-12-09.zip)
-> After unzipping the file, includes 16 different jar files in the folder. Upload all the jars using the library in databricks.
Please also include the below jars before running the code
1)twitter4j-core-4.0.6
2)spark-core_2.11-1.6.3
3)twitter4j-Stream-4.0.6
4)spark-streaming-twitter_2.11-1.6.3
5)standard-core-nlp-3.8.0-models.jar

-> Run each block.